# common/utils/response_helper.py
from fastapi.responses import JSONResponse

def success_response(status_code: int, message: str, data: dict = None):
    """ API အောင်မြင်ရင် ပြန်မည့် Response ပုံစံခွက် """
    return JSONResponse(
        status_code=status_code,
        content={
            "success": True,
            "message": message,
            "data": data or {}
        }
    )

def error_response(status_code: int, message: str):
    """ API Error တက်ရင် ပြန်မည့် Response ပုံစံခွက် """
    return JSONResponse(
        status_code=status_code,
        content={
            "success": False,
            "message": message,
            "data": None
        }
    )