
# import asyncpg
# from asyncpg.pool import Pool
# from contextlib import asynccontextmanager
# from typing import AsyncGenerator

# DB_CONFIG = {
#     "host": "localhost",
#     "port": 5432,
#     "user": "postgres",         
#     "password": "root",  
#     "db": "gymdb",        
#     "autocommit": True
# }
# async def get_db() -> AsyncGenerator[asyncpg.Connection, None]:
#     conn = await asyncpg.connect(**DB_CONFIG)
#     try:
#         yield conn
#     finally:
#         await conn.close()
import asyncpg
from typing import AsyncGenerator

# 💡 DB_CONFIG ကို PostgreSQL/asyncpg သတ်မှတ်ချက်အတိုင်း ပြင်ဆင်ထားပါသည်
DB_CONFIG = {
    "host": "localhost",
    "port": 5432,
    "user": "postgres",         
    "password": "root",  
    "database": "gymdb"  # 👈 'db' အစား 'database' ဟု ပြောင်းပေးပါ
}

async def get_db() -> AsyncGenerator[asyncpg.Connection, None]:
    # Connection စတင်ချိတ်ဆက်ခြင်း
    conn = await asyncpg.connect(**DB_CONFIG)
    try:
        yield conn
    finally:
        # Request ပြီးဆုံးပါက Connection ပြန်ပိတ်ခြင်း
        await conn.close()