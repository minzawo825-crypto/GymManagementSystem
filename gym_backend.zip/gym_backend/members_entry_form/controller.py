

import asyncpg
from fastapi import APIRouter, Depends, Request, HTTPException
from pydantic import BaseModel


from members_entry_form.model import MemberCreateRequest, MemberEntryList
from members_entry_form import service as members_entry_form_service
from database.core import get_db
from common.utils.logging_util import get_logger_with_request_id
import common.utils.response_helper as resp
from fastapi import APIRouter, Depends, Query, Request
from typing import Literal, Optional
import sys

from database.core import get_db
from common.utils.logging_util import get_logger_with_request_id
import common.utils.response_helper as resp



from auth.service import create_access_token
router = APIRouter()



class MemberDeleteRequest(BaseModel):
    syskey: str


@router.post("/entry/create_new_member")
async def member_entry(
    request: Request,
    body: MemberCreateRequest,
    db = Depends(get_db)
):
    logger = get_logger_with_request_id(request)
    try:
        result = await members_entry_form_service.create_new_member(db=db, request=body)
        
        if not result["success"]:
            return resp.error_response(status_code=400, message=result["message"])
            
        return resp.success_response(
            status_code=201,
            message=result["message"]
        )
        
    except Exception as e:
        print("======== CRITICAL MEMBER ENTRY ERROR ========")
        print(f"Error Type: {type(e).__name__} | Message: {str(e)}")
        import traceback; traceback.print_exc()
        print("=============================================")

        logger.error(
            "Error from Member Entry Endpoint",
            extra={"err_msg": f"{e} Error on Line {sys.exc_info()[-1].tb_lineno}"},
        )
        return resp.error_response(status_code=500, message="Internal Server Error")

@router.post("/entry/member_list")
async def get_member_list(
    request: Request,
    body: MemberEntryList,
    db=Depends(get_db),
):
    logger = get_logger_with_request_id(request)
    try:
        result = await members_entry_form_service.get_member_list(db=db, request=body)

        if not result["success"]:
            return resp.error_response(status_code=400, message=result["message"])

        return resp.success_response(
            status_code=200,
            message=result["message"],
            data=result["data"],
            pagination=result["pagination"],
        )
    except Exception as e:
        logger.error(
            "Error fetching member list data",
            extra={"err_msg": f"{e} Error on Line {sys.exc_info()[-1].tb_lineno}"},
        )
        return resp.error_response(status_code=500, message=str(e))
    

@router.post("/list")
async def get_all_members(db = Depends(get_db)):
    try:
        async with db.cursor() as cursor:
            await cursor.execute(
                "SELECT syskey, fullname, username, gender, contact, dor, address, amount, service, plan FROM members ORDER BY syskey ASC"
            )
            rows = await cursor.fetchall()
            
            result = []
            for row in rows:
                result.append({
                    "syskey": str(row[0]),
                    "fullname": row[1],
                    "username": row[2],
                    "gender": row[3],
                    "contact": row[4],
                    "dor": str(row[5]),
                    "address": row[6],
                    "amount": float(row[7]),
                    "service": row[8],
                    "plan": row[9]
                })
            return result
    except Exception as e:
        print(f"Error fetching member list: {str(e)}")
        return resp.error_response(status_code=500, message="Failed to fetch members")



@router.post("/remove")
async def remove_member(
    request: Request,
    payload: MemberDeleteRequest, 
    db = Depends(get_db)
):
    logger = get_logger_with_request_id(request)
    try:
        async with db.cursor() as cursor:
            await cursor.execute("DELETE FROM members WHERE syskey = %s", (payload.syskey,))
            await db.commit()
            
            if cursor.rowcount == 0:
                return resp.error_response(status_code=404, message="Member not found")
                
            return resp.success_response(
                status_code=200, 
                message="Member removed successfully"
            )
    except Exception as e:
        logger.error(f"Error removing member: {str(e)}")
        return resp.error_response(status_code=500, message="Internal Server Error")
# controller.py
from typing import Literal
from fastapi import APIRouter, Depends, Query, Request
import asyncpg
import sys

router = APIRouter()

@router.get("/dropdown")
async def get_dropdown_data(
    request: Request,
    type: Literal["gender", "plan", "service"] = Query(...),
    db: asyncpg.Connection = Depends(get_db),
):
    logger = get_logger_with_request_id(request)
    try:
        # Call service without 'token' parameter
        result = await members_entry_form_service.get_dropdown_data(type, db)

        return resp.success_response(
            status_code=200, 
            message="Success", 
            data={"data_list": result}
        )
    except Exception as e:
        logger.error(
            "Error from get_dropdown data",
            extra={"err_msg": f"{e} Error on Line {sys.exc_info()[-1].tb_lineno}"},
        )
        return resp.error_response(status_code=500, message=str(e))