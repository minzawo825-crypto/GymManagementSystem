# members/model.py
from pydantic import BaseModel, Field
from datetime import date
from typing import Optional

class MultiSearchModel(BaseModel):
    syskey: str
    # name: Optional[str] = None
class MemberCreateRequest(BaseModel):
    # Personal Info
    fullname: str = Field(..., description="Full Name of the member")
    username: str = Field(..., description="Unique Username")
    password: str = Field(..., description="Password for member login")
    gender: str = Field(..., description="Male / Female / Other")
    dor: date = Field(..., description="Date of Registration")
    plan: str = Field(..., description="e.g., One Month, Three Months, etc.")
    
    # Contact Details
    contact: str = Field(..., description="Phone number format (999) 999-999-999")
    address: str = Field(..., description="Living Address")
    
    # Service Details
    service: str = Field(..., description="Selected Service (e.g., Fitness, Sauna, Cardio)")
    amount: float = Field(..., description="Total Paid Amount")
    n1: int = 1  # status (1=active, 4=deleted) n1: int = 1  # status (1=active, 4=deleted)



class MemberEntryList(BaseModel):
    cur_page: int = 1
    page_size: int = 25
   
    fullname: Optional[str] = None
    username: Optional[str] = None
    gender: Optional[str] = None
    plan: Optional[str] = None
    contact: Optional[str] = None
    address: Optional[str] = None
    service: Optional[str] = None
    amount: Optional[float] = None
    n1: int = 1  # status (1=active, 4=deleted)