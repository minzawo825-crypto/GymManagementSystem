
import math
import uuid
import asyncpg
from members_entry_form.model import MemberCreateRequest

# ==========================================
# 1. CREATE NEW MEMBER
# ==========================================
import uuid
import asyncpg
from members_entry_form.model import MemberCreateRequest

async def create_new_member(
    db: asyncpg.Connection, 
    request: MemberCreateRequest, 
    created_by_user: str = "SYSTEM" # Or pass the logged-in user
) -> dict:
    try:
        
        check_query = "SELECT syskey FROM members WHERE t2 = $1"
        existing_user = await db.fetchrow(check_query, request.username)
        
        if existing_user:
            return {
                "success": False, 
                "message": "Username is already taken. Please choose a different username."
            }
        
        #
        syskey = f"MEM-{uuid.uuid4().hex[:8].upper()}"
        
        
        insert_query = """
            INSERT INTO members (
                syskey, t1, t2, t3, t4, t5, t6, t7, t8, t9, t10, n1, createddate, createdby
            ) 
            VALUES (
                $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, NOW(), $13
            )
            RETURNING autokey, syskey;
        """

        result = await db.fetchrow(
            insert_query,
            syskey,                 # $1 -> syskey
            request.fullname,       # $2 -> t1
            request.username,       # $3 -> t2
            request.password,       # $4 -> t3 (Tip: Hash this using bcrypt!)
            request.address,        # $5 -> t4
            str(request.dor),       # $6 -> t5 (Date to string)
            request.plan,           # $7 -> t6
            request.gender,         # $8 -> t7
            request.contact,        # $9 -> t8
            request.service,        # $10 -> t9
            request.amount,         # $11 -> t10
            request.n1,             # $12 -> n1
            created_by_user         # $13 -> createdby
        )
        
        return {
            "success": True,
            "message": "New Member added successfully",
            "data": {
                "autokey": result["autokey"],
                "syskey": result["syskey"]
            }
        }
    except Exception as e:
        return {
            "success": False,
            "message": f"Database Error: {str(e)}"
        }


# ==========================================
# 2. GET PAGINATED & FILTERED MEMBER LIST
# ==========================================
async def get_member_list(db: asyncpg.Connection, request) -> dict:
    """
    Fetch paginated and filtered member list (PostgreSQL Version).
    """
    try:
        cur_page = request.cur_page if request.cur_page > 0 else 1
        page_size = request.page_size if request.page_size > 0 else 10
        offset = (cur_page - 1) * page_size

        # Base Queries
        base_where = " WHERE n1 = 1"
        params = []
        param_index = 1

        # Dynamic Filters Construction
        filters = [
            ("fullname", request.fullname, "LIKE"),
            ("username", request.username, "LIKE"),
            ("gender", request.gender, "="),
            ("plan", request.plan, "="),
            ("contact", request.contact, "LIKE"),
            ("address", request.address, "LIKE"),
            ("service", request.service, "="),
        ]

        for field, value, operator in filters:
            if value:
                if operator == "LIKE":
                    base_where += f" AND {field} ILIKE ${param_index}"
                    params.append(f"%{value}%")
                else:
                    base_where += f" AND {field} = ${param_index}"
                    params.append(value)
                param_index += 1

        # Get Total Count
        count_query = f"SELECT COUNT(*) FROM members{base_where}"
        total_count = await db.fetchval(count_query, *params)
        total_count = total_count if total_count else 0
        total_pages = math.ceil(total_count / page_size) if total_count > 0 else 1

        # Main Query With Pagination
        query = f"""
            SELECT 
                syskey, fullname, username, gender, dor, plan,
                contact, address, service, amount
            FROM members
            {base_where}
            ORDER BY autokey DESC 
            LIMIT ${param_index} OFFSET ${param_index + 1}
        """
        
        fetch_params = params + [page_size, offset]
        rows = await db.fetch(query, *fetch_params)
        
        
        result_data = [dict(row) for row in rows]

        return {
            "success": True,
            "message": "Member list fetched successfully",
            "data": result_data,
            "pagination": {
                "cur_page": cur_page,
                "page_size": page_size,
                "total_count": total_count,
                "total_pages": total_pages,
            },
        }
    except Exception as e:
        return {
            "success": False,
            "message": str(e),
        }


# ==========================================
# 3. GET DROPDOWN DATA
# ==========================================
# service.py
import asyncpg

# service.py
import asyncpg

async def get_dropdown_data(type_param: str, db: asyncpg.Connection):
    """
    Fetches dropdown options dynamically based on the type parameter.
    """
    
    queries = {
        "gender": """
            SELECT syskey, t1 
            FROM gender 
            ORDER BY autokey ASC;
        """,
        "plan": """
            SELECT syskey, t1 
            FROM plan 
            ORDER BY autokey ASC;
        """,
        "service": """
            SELECT syskey, t1, CAST(t2 AS TEXT) as t2 
            FROM service 
            ORDER BY autokey ASC;
        """
    }

    query = queries.get(type_param)
    if not query:
        return []

    # Execute asyncpg query
    records = await db.fetch(query)
    
    # Convert asyncpg Record objects to a list of dicts
    result = []
    for row in records:
        data = {
            "syskey": str(row["syskey"]),
            "t1": str(row["t1"])
        }
        if "t2" in row and row["t2"] is not None:
            data["t2"] = str(row["t2"])
        result.append(data)

    return result