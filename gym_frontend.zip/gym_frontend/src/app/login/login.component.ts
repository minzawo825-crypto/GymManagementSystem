import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../services/auth.service';
import { CommonModule } from '@angular/common'; // HTML မှာ errorMessage ပြသရန် ထည့်ပါ

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule],
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginForm!: FormGroup;
  errorMessage = '';

  constructor(
    private authService: AuthService,
    private router: Router,
    private formBuilder: FormBuilder
  ) {}

  ngOnInit(): void {
    localStorage.clear();
    sessionStorage.clear();

    this.loginForm = this.formBuilder.group({
      username: ['', [Validators.required]],
      // Password length နည်းတာကြောင့် Submit မထွက်တာ မဖြစ်ရအောင် minLength validation ကို ယာယီဖြုတ် သို့မဟုတ် စစ်ဆေးပါ
      password: ['', [Validators.required]] 
    });
  }
    
  onSubmit(): void {
    this.errorMessage = ''; // Error message အဟောင်းများကို clear လုပ်ရန်

    if (this.loginForm.invalid) {
      this.loginForm.markAllAsTouched();
      return;
    }

    this.authService.login(this.loginForm.value).subscribe({
      next: (response) => {
        console.log('Login Response:', response); // Debugging အတွက် Log ထုတ်ကြည့်ရန်

        // 💡 resp.success_response Structure အတိုင်း စစ်ဆေးခြင်း
        if ((response.status_code === 200 || response.data) && response.data?.access_token) {

          // LocalStorage ထဲသို့ Token နှင့် User Info ထည့်သွင်းခြင်း
          localStorage.setItem('token', response.data.access_token);
          if (response.data.user?.username) {
            localStorage.setItem('username', response.data.user.username);
          }

          // Dashboard သို့ လမ်းကြောင်းပြောင်းခြင်း
          this.router.navigate(['Dashboard']);
        } else {
          this.errorMessage = response.message || 'Login failed. Invalid response from server.';
        }
      },

      error: (err) => {
        console.error('Login Error:', err);
        // Backend မှ error response Message ကို ယူယူပြီး UI တွင် ပြသပေးခြင်း
        this.errorMessage =
          err.error?.message ||
          'Login Failed. Please check your credentials and try again.';
      }
    });
  }
}