// src/app/member-entry/member-entry.component.ts
import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { MemberService, AllDropdowns, DropdownOption } from '../services/member.service';

@Component({
  selector: 'app-member-entry',
  standalone: true, // 1. Set component as standalone
  imports: [CommonModule, ReactiveFormsModule], // 2. Add directives and pipes directly here
  templateUrl: './member-entry.component.html',
  styleUrls: ['./member-entry.component.css']
})
export class MemberEntryComponent implements OnInit {
  memberForm!: FormGroup;
  dropdowns!: AllDropdowns;
  isLoading = true;

  constructor(
    private fb: FormBuilder,
    private memberService: MemberService
  ) {}

  ngOnInit(): void {
    this.initForm();
    this.loadDropdowns();
    this.listenToServiceChange();
  }

  private initForm(): void {
    this.memberForm = this.fb.group({
      fullname: ['', Validators.required],
      username: ['', Validators.required],
      password: ['', Validators.required],
      genderSyskey: ['', Validators.required],
      dor: [new Date().toISOString().substring(0, 10), Validators.required],
      planSyskey: ['', Validators.required],
      contact: ['', Validators.required],
      address: ['', Validators.required],
      serviceSyskey: ['', Validators.required],
      amount: [{ value: 0, disabled: true }, Validators.required]
    });
  }

  private loadDropdowns(): void {
    this.memberService.getDropdowns().subscribe({
      next: (data: AllDropdowns) => {
        this.dropdowns = data;
        this.isLoading = false;

        if (data.genders.length) {
          this.memberForm.patchValue({ genderSyskey: data.genders[0].syskey });
        }
        if (data.plans.length) {
          this.memberForm.patchValue({ planSyskey: data.plans[0].syskey });
        }
        if (data.services.length) {
          this.memberForm.patchValue({
            serviceSyskey: data.services[0].syskey,
            amount: Number(data.services[0].t2 || 0)
          });
        }
      },
      error: (err) => {
        console.error('Failed to load dropdowns', err);
        this.isLoading = false;
      }
    });
  }

  private listenToServiceChange(): void {
    this.memberForm.get('serviceSyskey')?.valueChanges.subscribe((syskey: string) => {
      const selectedService = this.dropdowns?.services.find((s) => s.syskey === syskey);
      if (selectedService && selectedService.t2) {
        this.memberForm.patchValue({ amount: Number(selectedService.t2) });
      }
    });
  }

  onSubmit(): void {
    if (this.memberForm.invalid) {
      this.memberForm.markAllAsTouched();
      return;
    }

    const formPayload = this.memberForm.getRawValue();

    this.memberService.addMember(formPayload).subscribe({
      next: () => {
        alert('Member added successfully!');
        this.memberForm.reset({
          dor: new Date().toISOString().substring(0, 10),
          genderSyskey: this.dropdowns?.genders[0]?.syskey || '',
          planSyskey: this.dropdowns?.plans[0]?.syskey || '',
          serviceSyskey: this.dropdowns?.services[0]?.syskey || '',
          amount: Number(this.dropdowns?.services[0]?.t2 || 0)
        });
      },
      error: (err) => {
        console.error('Error creating member', err);
      }
    });
  }
}