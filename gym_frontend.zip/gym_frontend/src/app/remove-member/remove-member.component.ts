// src/app/remove-member/remove-member.component.ts
import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MemberService } from '../services/member.service';

@Component({
  selector: 'app-remove-member',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './remove-member.component.html',
  styleUrls: ['./remove-member.component.css']
})
export class RemoveMemberComponent implements OnInit {
  members: any[] = [];
  isLoading = true;

  constructor(private memberService: MemberService) {}

  ngOnInit(): void {
    this.fetchMembers();
  }

  fetchMembers(): void {
    this.isLoading = true;
    this.memberService.getMembers().subscribe({
      next: (data) => {
        this.members = Array.isArray(data) ? data : [];
        this.isLoading = false;
      },
      error: (err) => {
        console.error('Error fetching members:', err);
        this.isLoading = false;
      }
    });
  }

  // Remove Action Handler
  remove(syskey: string): void {
    if (!confirm('ဒီအဖွဲ့ဝင်ကို စာရင်းထဲမှ ဖျက်ပစ်ရန် သေချာပါသလား?')) {
      return;
    }

    this.memberService.removeMember(syskey).subscribe({
      next: () => {
        alert('အဖွဲ့ဝင်ကို အောင်မြင်စွာ ဖျက်ပြီးပါပြီ');
        this.fetchMembers(); // Data များ ပြန်လည် Reload လုပ်မည်
      },
      error: (err) => {
        console.error('Error removing member:', err);
        alert('ဖျက်ရာတွင် အမှားတစ်ခု ဖြစ်ပေါ်ခဲ့ပါသည်။');
      }
    });
  }
}